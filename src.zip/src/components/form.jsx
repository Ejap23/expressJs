import React, {useState} from "react";
import axios from 'axios';
import './form.css';


function Form() {
    const [user, setUser] = useState({
        email:'',
        password: '',
       
      });
      
    
      const handleSubmit = async (e) => {
        e.preventDefault();
    
        try {
          const response = await axios.post('http://localhost:3001/users/', user);
          console.log(response.data);
          alert("log in successful");
          
        } catch (error) {
          console.error('Error sending user data', error);
        }
      };
    
      const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
        
      };

    
    return (
       
        <form onSubmit={handleSubmit}>
        <label>
          Fullname:
          <input  type="text" name="email" value={user.email} onChange={handleChange} />
        </label>
        <label>
          Email:
          <input  type="email" name="password" value={user.password} onChange={handleChange} />
        </label>
   
        <button type="submit">Submit</button>
      </form>
      
    );
  }
  
  export default Form;